<?php 
class validationerr extends ValidateRule{
    public function FetchErr()
    {
        print_r($this->errors);
    }
    
}
?>