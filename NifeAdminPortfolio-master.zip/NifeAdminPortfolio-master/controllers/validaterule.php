<?php 
// validation rule 
class ValidateRule{
    public $data;// the post request array
    public $DB;// con driver
    public $errors =[];// all validation errors go here
    //a construct is the first function triggered once the instance of the class is created
    public function _construct( $data ,$DB)
    {
        # code...
        $this->data = $data;
        $this->DB=$DB;
    }
    function testimput($input){
        $value= trim($input);//takes out whitespaces 
        $value = stripslashes($value);// takes out foward slashes and back slashes
       $value= htmlspecialchars($value);//converts special characters to html
       $value = $this->DB->real_escape_string($value);

       return $value;
         
    } 
    public function isEmpty($input)
    {
        if (empty($input)){
         $this->addError($input,'i dont know') ;  
        }
    }
    public function addError($key, $value)
    {
       $this->errors[$key] = $value ;
    }
    
}

?>